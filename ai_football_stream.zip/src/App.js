import React from "react";
import { AuthModule, AiMatchEngine, Database, VideoPlayer, NotificationService, AiTeamFactory, CommentaryEngine, LiveCommentary, SubscriptionService } from "./modules";

export default function App() {
  const auth = AuthModule();
  const aiEngine = AiMatchEngine();
  const teamFactory = AiTeamFactory();
  const subscription = SubscriptionService();

  const [user, setUser] = React.useState(null);
  const [currentMatch, setCurrentMatch] = React.useState(aiEngine.generateMatch());
  const [plan, setPlan] = React.useState('Free');

  React.useEffect(() => { Database.saveMatch(currentMatch); }, []);

  const handleLogin = async () => {
    const response = await auth.login('joao@example.com', '123456');
    if(response.success) setUser({ email: 'joao@example.com' });
  };

  const handleSubscribe = (planName) => {
    const response = subscription.subscribe(user?.email || 'guest', planName);
    if(response.success) setPlan(planName);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">AI Football Stream</h1>
        <p className="text-lg mt-2">Streaming gerado por Inteligência Artificial (sem direitos autorais)</p>
        {user ? <p className="mt-2">Bem-vindo, {user.email}</p> : <button onClick={handleLogin} className="mt-2 p-2 bg-blue-600 rounded">Login</button>}
      </header>

      <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-gray-800 p-4 rounded-2xl shadow-lg">
          <h2 className="text-2xl mb-4 font-semibold">Jogo em Destaque (Gerado por IA)</h2>
          <VideoPlayer url={currentMatch.streamUrl} />
          <h3 className="mt-4 text-xl font-semibold">Comentários ao Vivo</h3>
          <LiveCommentary match={currentMatch} />
        </div>

        <div className="bg-gray-800 p-4 rounded-2xl shadow-lg">
          <h2 className="text-xl mb-4 font-semibold">Próximos Jogos AI</h2>
          {Database.getUpcoming().map((m, idx) => (
            <div key={idx} className="bg-gray-700 p-3 rounded-xl mb-2 cursor-pointer hover:bg-gray-600">
              {m.home} vs {m.away} - {m.startTime}
            </div>
          ))}

          <h2 className="text-xl mt-6 mb-4 font-semibold">Planos de Assinatura</h2>
          {subscription.getPlans().map((p, idx) => (
            <div key={idx} className="bg-gray-700 p-3 rounded-xl mb-2">
              <p className="font-semibold">{p.name} - ${p.price}</p>
              <ul className="text-gray-300 mb-2">
                {p.benefits.map((b, i) => <li key={i}>• {b}</li>)}
              </ul>
              <button onClick={() => handleSubscribe(p.name)} className="p-1 bg-green-600 rounded">Assinar</button>
            </div>
          ))}
        </div>
      </main>

      <section id="features" className="mt-16 bg-gray-800 p-6 rounded-2xl shadow-xl">
        <h2 className="text-3xl font-bold mb-6 text-center">Funcionalidades Principais</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-700 p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">🎮 Jogos Criados por IA</h3>
            <p>Simulação avançada de partidas com equipas geradas por IA, com estilos únicos, jogadores fictícios e táticas inovadoras.</p>
          </div>
          <div className="bg-gray-700 p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">📺 Streaming 24/7</h3>
            <p>Transmissões ininterruptas de jogos AI sem direitos autorais. Ideal para monetização global.</p>
          </div>
          <div className="bg-gray-700 p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">🧠 Motor de Simulação IA</h3>
            <p>Engine proprietário de criação de partidas com física, comentários e narração gerados por IA.</p>
          </div>
        </div>
      </section>

      <section id="upcoming-ai-matches" className="mt-16">
        <h2 className="text-3xl font-bold mb-6">Próximos Jogos AI</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Database.getUpcoming().map((match, idx) => (
            <div key={idx} className="bg-gray-800 p-4 rounded-xl shadow-lg">
              <h3 className="text-xl font-semibold">{match.home} vs {match.away}</h3>
              <p className="text-gray-400">Gerado às {match.startTime}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="text-center mt-10 text-gray-400">
        <p>© 2025 AI Football Stream. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
